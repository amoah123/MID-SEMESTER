<?php
// Database connection (XAMPP default: user=root, no password)
$conn = new mysqli("localhost", "root", '', "study_planner");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = $_POST['subject'];
    $task = $_POST['task'];
    $study_date = $_POST['study_date'];

    $stmt = $conn->prepare("INSERT INTO plans (subject, task, study_date) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $subject, $task, $study_date);
    $stmt->execute();
}

// Fetch planner tasks
$result = $conn->query("SELECT * FROM plans ORDER BY study_date ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Study Planner</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">

    <h1 class="planner-title">Student Study Planner</h1>

<!-- Form -->
<form method="POST" class="planner-form">

  <label for="subject">Subject</label>
  <input type="text" id="subject" name="subject" placeholder="eg. Mathematics" required>

  <label for="task">Task</label>
  <textarea id="task" name="task" placeholder="Describe the study task ..." required></textarea>

  <label for="study_date">Date</label>
  <input type="date" id="study_date" name="study_date" required>

  <button type="submit">Add to Planner</button>
</form>



    <!-- Planner Display -->
    <h2>📝 Your Study Plan</h2>
    <div class="planner-list">
      <?php while ($row = $result->fetch_assoc()): ?>
        <div class="planner-item">
          <h3><?= htmlspecialchars($row['subject']) ?></h3>
          <p><?= htmlspecialchars($row['task']) ?></p>
          <span class="date"><?= htmlspecialchars($row['study_date']) ?></span>
        </div>
      <?php endwhile; ?>
    </div>

  </div>
  <script src="script.js"></script>
</body>
</html>
