document.querySelector(".planner-form").addEventListener("submit", function() {
    alert("✅ Task added to your planner!");
});
